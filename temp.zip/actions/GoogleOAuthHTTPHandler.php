<?php

global $root_directory;
require_once($root_directory . "/modules/RedooCalendar/autoload_wf.php");

use RedooCalendar\Base\Database;
use RedooCalendar\Base\Exception\DatabaseException;
use RedooCalendar\Base\ActionController\BaseActionController;
use RedooCalendar\Model\Connection;

class RedooCalendar_GoogleOAuthHTTPHandler
{

    public function handle($data)
    {
        global $site_URL;
        $request = new Vtiger_Request($_REQUEST);

        try {
            Database::startTransaction();

            $googleConnection = new Connection();
            $googleConnection->fetch($request->get('state')['connection_id']);
            $googleConnection->setSettings(json_encode([
                'access_token' => $request->get('code'),
                'scope' => $request->get('scope')
            ]));
            $googleConnection->save();
            Database::commitTransaction();

            echo '<script>window.location="'.$site_URL . 'index.php?module=RedooCalendar&view=List"</script>';
            exit();
        } catch (DatabaseException $databaseException) {
            Database::rollbackTransaction();
            echo json_encode([
                'status' => false,
                'message' => 'Database error, please contact administrator'
            ]);
        } catch (\Exception $exception) {
            Database::rollbackTransaction();
            echo json_encode([
                'status' => false,
                'message' => 'Some error occurred, please contact administrator',
                'exception' => $exception->getMessage(),
            ]);
        }

        return;
    }
}
