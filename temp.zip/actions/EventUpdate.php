<?php

global $root_directory;
require_once($root_directory . "/modules/RedooCalendar/autoload_wf.php");

use RedooCalendar\Base\Connection\Connection;
use RedooCalendar\Base\Database;
use RedooCalendar\Base\Exception\DatabaseException;
use RedooCalendar\Base\ActionController\BaseActionController;

class RedooCalendar_EventUpdate_Action extends BaseActionController
{

    function checkPermission(Vtiger_Request $request)
    {
        return true;
    }

    public function process(Vtiger_Request $request)
    {
        try {
            Database::startTransaction();

            $connection = Connection::GetInstance($request->get('connector'));

            if($connection->getCode() === 'shared') {
                $sql = 'select *
                        from vtiger_redoocalendar_calendar_permission
                                 left join vtiger_redoocalendar_subscribe
                                           on vtiger_redoocalendar_calendar_permission.calendar_id = vtiger_redoocalendar_subscribe.id
                                 left join vtiger_redoocalendar_connections vrc on vtiger_redoocalendar_subscribe.connection_id = vrc.id
                        where vtiger_redoocalendar_calendar_permission.user_id = ? and vtiger_redoocalendar_subscribe.calendar_id = ?';

                $adb = PearDatabase::getInstance();

                /** @var ADORecordSet_mysqli $result */
                $result = $adb->pquery($sql, [Users_Record_Model::getCurrentUserModel()->getId(), $request->get('calendar_id')]);
                $connectionId = (int)$result->Fields('connection_id');
                $connection = Connection::GetInstance($connectionId);
            }


            $event = $connection->getConnector()->updateEvent($request);
            Database::commitTransaction();

            echo json_encode([
                'status' => true,
                'event' => $event->getData(),
                'connector' => $connection->getData(),
                'collection' => $connection->getConnector()->getSubscribedCalendarCollection(),
                'message' => self::t('Event Successfully Updated'),
            ]);
        } catch (DatabaseException $databaseException) {
            Database::rollbackTransaction();
            echo json_encode([
                'status' => false,
                'test' => $databaseException->getMessage(),
                'message' => self::t(RedooCalendar::DATABASE_EXCEPTION_MESSAGE)
            ]);
        } catch (\Exception $exception) {

            Database::rollbackTransaction();
            echo json_encode([
                'status' => false,
                'test' => $exception->getMessage(),
                'message' => self::t(RedooCalendar::EXCEPTION_MESSAGE)
            ]);
        }

        return;
    }

    public function validateRequest(Vtiger_Request $request)
    {
        $request->validateReadAccess();
    }

}
