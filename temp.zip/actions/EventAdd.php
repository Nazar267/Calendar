<?php

global $root_directory;
require_once($root_directory . "/modules/RedooCalendar/autoload_wf.php");

use RedooCalendar\Base\Connection\Connection;
use RedooCalendar\Base\Database;
use RedooCalendar\Base\Exception\DatabaseException;
use RedooCalendar\Base\ActionController\BaseActionController;

class RedooCalendar_EventAdd_Action extends BaseActionController
{

    function checkPermission(Vtiger_Request $request)
    {
        return true;
    }

    public function process(Vtiger_Request $request)
    {
        try {
            Database::startTransaction();

            $connection = Connection::GetInstance($request->get('connector'));

            if($connection->getCode() === 'shared') {
                $sql = 'select *
                        from vtiger_redoocalendar_calendar_permission
                                 left join vtiger_redoocalendar_subscribe
                                           on vtiger_redoocalendar_calendar_permission.calendar_id = vtiger_redoocalendar_subscribe.id
                                 left join vtiger_redoocalendar_connections vrc on vtiger_redoocalendar_subscribe.connection_id = vrc.id
                        where vtiger_redoocalendar_calendar_permission.user_id = ? and vtiger_redoocalendar_subscribe.calendar_id = ?';

                $adb = PearDatabase::getInstance();

                /** @var ADORecordSet_mysqli $result */
                $result = $adb->pquery($sql, [Users_Record_Model::getCurrentUserModel()->getId(), $request->get('calendar_id')]);
                $connectionId = (int)$result->Fields('connection_id');
                $connection = Connection::GetInstance($connectionId);
            }

            $event = $connection->getConnector()->createEvent($request);
            Database::commitTransaction();

            echo json_encode([
                'status' => true,
                'event' => $event->getData(),
                'collection' => $this->getConnector()->getSubscribedCalendarCollection(),
                'message' => self::t('Event Successfully Added')
            ]);
        } catch (DatabaseException $databaseException) {
            Database::rollbackTransaction();
            echo json_encode([
                'status' => false,
                'message' =>  self::t(RedooCalendar::DATABASE_EXCEPTION_MESSAGE)
            ]);
        } catch (\Exception $exception) {
            var_dump($exception);
            Database::rollbackTransaction();
            echo json_encode([
                'status' => false,
                'message' => self::t(RedooCalendar::EXCEPTION_MESSAGE)
            ]);
        }

        return;
    }

    public function validateRequest(Vtiger_Request $request)
    {
        $request->validateReadAccess();
    }

}
