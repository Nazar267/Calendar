<?php

global $root_directory;
require_once($root_directory . "/modules/RedooCalendar/autoload_wf.php");

use RedooCalendar\Base\ActionController\BaseActionController;

class RedooCalendar_GetEventSourceData_Action extends BaseActionController
{

    function checkPermission(Vtiger_Request $request)
    {
        return true;
    }

    public static function getTaskStatusData(): array
    {
        global $adb;
        $resp = [];

        $result = $adb->pquery("select projecttaskstatus from vtiger_projecttaskstatus");
        while ($data = $adb->fetch_array($result)) {
            $row = [
                $data["projecttaskstatus"] => vtranslate($data["projecttaskstatus"], 'ProjectTask')
            ];

            $resp = array_merge((array)$resp, (array)$row);
        }

        return $resp;

    }

    public static function getTaskTypeData(): array
    {
        global $adb;
        $resp = [];

        $result = $adb->pquery("select projecttasktype from vtiger_projecttasktype");
        while ($data = $adb->fetch_array($result)) {
            $row = [
                $data["projecttasktype"] => vtranslate($data["projecttasktype"], 'ProjectTask')
            ];

            $resp = array_merge((array)$resp, (array)$row);
        }

        return $resp;

    }

    public function process(Vtiger_Request $request)
    {
        return;
    }

    public function validateRequest(Vtiger_Request $request)
    {
        $request->validateReadAccess();
    }

}
