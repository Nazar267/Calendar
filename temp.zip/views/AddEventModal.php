<?php


global $root_directory;
require_once($root_directory . "/modules/RedooCalendar/autoload_wf.php");

use RedooCalendar\Base\View\BaseView;
use RedooCalendar\Base\Connection\Connection;
use RedooCalendar\Base\Connection\ConnectorPlugin\ConnectorPluginInterface;
use RedooCalendar\Base\EventForm as Form;


class RedooCalendar_AddEventModal_View extends BaseView
{
    public function process(Vtiger_Request $request)
    {
         $connection = Connection::GetInstance($request->get('connector'));

        if($connection->getCode() === 'shared') {
            $sql = 'select *
                        from vtiger_redoocalendar_calendar_permission
                                 left join vtiger_redoocalendar_subscribe
                                           on vtiger_redoocalendar_calendar_permission.calendar_id = vtiger_redoocalendar_subscribe.id
                                 left join vtiger_redoocalendar_connections vrc on vtiger_redoocalendar_subscribe.connection_id = vrc.id
                        where vtiger_redoocalendar_calendar_permission.user_id = ? and vtiger_redoocalendar_subscribe.calendar_id = ?';

            $adb = PearDatabase::getInstance();

            /** @var ADORecordSet_mysqli $result */
            $result = $adb->pquery($sql, [Users_Record_Model::getCurrentUserModel()->getId(), $request->get('calendar_id')]);
            $connectionId = (int)$result->Fields('connection_id');

            $connection = Connection::GetInstance($connectionId);
        }

        $connectionData = $connection->getData();
        $connection = $connection->getConnector();

        if (!$connection) {
            echo json_encode([
                'success' => false
            ]);
            return;
        }
        $form = $connection->getEventConfigForm();

        echo json_encode([
            'form' => $form->getFrontendData(),
            'connector' =>  Connection::GetInstance($request->get('connector'))->getData(),
            'model' => $connection->getEventModel()
        ]);
        return;
    }
}
