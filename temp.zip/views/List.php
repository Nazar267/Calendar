<?php

global $root_directory;

use RedooCalendar\Base\View\BaseView;

require_once($root_directory . "/modules/RedooCalendar/autoload_wf.php");

class RedooCalendar_List_View extends BaseView
{
    public function process(Vtiger_Request $request)
    {
        $viewer = $this->getViewer($request);
        $this->getDocumentation($request);

        $viewer->view('Index.tpl', $request->getModule(false));
    }

    /**
     * @param \Vtiger_Request $request
     *
     * @return Vtiger_JsScript_Model[]
     */
    function getHeaderScripts(Vtiger_Request $request)
    {
        $headerScriptInstances = parent::getHeaderScripts($request);

        $jsFileNames = array(
            "~modules/RedooCalendar/views/resources/js/FlexUtils.min.js",
            "~modules/RedooCalendar/views/resources/js/formhandler.js",
            "https://kendo.cdn.telerik.com/2019.1.115/js/kendo.all.min.js",
            "https://cdnjs.cloudflare.com/ajax/libs/validate.js/0.13.1/validate.min.js",
            "https://cdnjs.cloudflare.com/ajax/libs/jquery-contextmenu/2.7.1/jquery.contextMenu.min.js",
            "https://cdnjs.cloudflare.com/ajax/libs/jquery-contextmenu/2.7.1/jquery.ui.position.js",
            "https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js",
            "~modules/RedooCalendar/views/resources/js/complexecondition2.js",
            "~modules/RedooCalendar/views/resources/public/build/app.js",
        );

        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);

        return $headerScriptInstances;
    }

    /**
     * @param \Vtiger_Request $request
     *
     * @return \Vtiger_CssScript_Model[]
     */
    function getHeaderCss(Vtiger_Request $request)
    {
        $headerScriptInstances = parent::getHeaderCss($request);

        $cssFileNames = array(
            'https://kendo.cdn.telerik.com/2019.1.115/styles/kendo.common.min.css',
            'https://cdnjs.cloudflare.com/ajax/libs/jquery-contextmenu/2.7.1/jquery.contextMenu.min.css',
            '~modules/RedooCalendar/views/resources/public/build/style.css'
        );

        $cssScriptInstances = $this->checkAndConvertCssStyles($cssFileNames);
        $headerStyleInstances = array_merge($headerScriptInstances, $cssScriptInstances);

        return $headerStyleInstances;
    }

}
