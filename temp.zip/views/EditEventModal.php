<?php


global $root_directory;
require_once($root_directory . "/modules/RedooCalendar/autoload_wf.php");

use RedooCalendar\Base\Form\Field;
use RedooCalendar\Base\Form\Type;
use RedooCalendar\Base\Form\Type\Hidden;
use RedooCalendar\Base\View\BaseView;
use RedooCalendar\Base\Connection\Connection;
use RedooCalendar\Base\Connection\ConnectorPlugin\ConnectorPluginInterface;
use RedooCalendar\Base\EventForm as Form;


class RedooCalendar_EditEventModal_View extends BaseView
{
    public function process(Vtiger_Request $request)
    {
        $form = new Form();
        $form->setFormId('create-event');
        $form->setWidth(600);

        $calendar_id = $request->get('calendar_id');

        $connection = Connection::GetInstance($request->get('connector'));

        if($connection->getCode() === 'shared') {
            $sql = 'select *
                        from vtiger_redoocalendar_calendar_permission
                                 left join vtiger_redoocalendar_subscribe
                                           on vtiger_redoocalendar_calendar_permission.calendar_id = vtiger_redoocalendar_subscribe.id
                                 left join vtiger_redoocalendar_connections vrc on vtiger_redoocalendar_subscribe.connection_id = vrc.id
                        where vtiger_redoocalendar_calendar_permission.user_id = ? and vtiger_redoocalendar_subscribe.calendar_id = ?';

            $adb = PearDatabase::getInstance();

            /** @var ADORecordSet_mysqli $result */
            $result = $adb->pquery($sql, [Users_Record_Model::getCurrentUserModel()->getId(), $request->get('calendar_id')]);
            $connectionId = (int)$result->Fields('connection_id');
            $connection = Connection::GetInstance($connectionId);
        }

        $calendar = $connection->getConnector()->getCalendar($request->get('calendar_id'));
        $event = $connection->getConnector()->getEvent($calendar, $request->get('id'));

        if (!$connection) {
            echo json_encode([
                'success' => false
            ]);
            return;
        }
        $eventConfig = $connection->getConnector()->getEventConfig();

        if(!isset($event['date_start'])){
            $event['date_start'] = $event['date_from'];
            unset($event['date_from']);
        }
        if(!isset($event['date_end'])){
            $event['date_end'] = $event['due_date'];
            unset($event['due_date']);
        }


        foreach ($eventConfig as $eventTypeCode => $eventType) {
            $tab = $form->addTab($eventType['headline']);
            $tab->setModel($eventType['model']);
            $group = null;
            foreach ($eventType['blocks'] as $blockName => $block) {
                $group = $tab->addGroup($block['headline']);
                $group->setColumCount($block['column_count']);

                foreach ($block['fields'] as $field) {
                    $_field = $group->addField()
                        ->setId($field['id'])
                        ->setBindValue($field['name'])
                        ->setLabel($field['headline'])
                        ->setPath([$eventTypeCode])
                        ->setValue($event->getData($field['name']))
                        ->setName($field['name'])
                        ->setType($field['type']);

                    if($field['related']) {
                        $_field->setRelated($field['related']);
                    }

                    if (isset($field['options'])) {
                        foreach ($field['options']['options'] as &$option) {
                            $option = self::t($option);
                        }
                        $_field->setOptions($field['options']);
                    }

                    if (isset($field['validator'])) {
                        $_field->addValidator(new $field['validator']());
                    }
                }
            }
            $group->addField()
                ->setId('id')
                ->setBindValue('id')
                ->setValue($event->getData('id'))
                ->setName('id')
                ->setType(Field::INPUT_HIDDEN);

            $group->addField()
                ->setId('calendar_id')
                ->setBindValue('calendar_id')
                ->setValue($calendar->getId())
                ->setName('calendar_id')
                ->setType(Field::INPUT_HIDDEN);

            $group->addField()
                ->setId('connector')
                ->setBindValue('connector')
                ->setValue($connection->getId())
                ->setName('connector')
                ->setType(Field::INPUT_HIDDEN);
        }


        echo json_encode([
            'form' => $form->getFrontendData(),
            'connector' => $connection->getData(),
            'model' => reset($eventConfig)['model']
        ]);
        return;
    }
}
