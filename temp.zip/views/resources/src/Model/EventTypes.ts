import {EventInterface} from "./Event/Interface";
import {Event} from "./Event";
import * as _ from "lodash";
import {Model} from "../Core/Model/Model";


export namespace EventTypes {

    export class RedooEvent extends Event implements EventInterface {
        data: {
            id: '',
            title: 'RedooEvent',
            description: 'RedooEvent',
            calendar_id: '',
            relations: {},
            date_start: DateConstructor,
            date_start_timestamp: 0,
            date_end: DateConstructor,
            date_end_timestamp: 0,
            code: '',
            connector: 0,
            all_day_event: false,
            activitytype: '',
            taskstatus: '',
            eventstatus: '',
            read_only: false,
        };

        public publicData = [
            'id',
            'title',
            'calendar_id',
            'date_start_timestamp',
            'date_end_timestamp',
            'code',
            'connector',
            'description',
            'activitytype',
            'eventstatus',
        ]
    }

    export class RedooTask extends Event implements EventInterface {
        data: {
            id: '',
            description: 'RedooTask',
            title: 'RedooTask',
            calendar_id: '',
            relations: {},
            date_start: DateConstructor,
            date_start_timestamp: 0,
            date_end: DateConstructor,
            date_end_timestamp: 0,
            code: '',
            connector: 0
            all_day_event: true,
            taskstatus: '',
            eventstatus: '',
            activitytype: '',
            read_only: false,
        };

        public publicData = [
            'id',
            'title',
            'calendar_id',
            'date_start_timestamp',
            'date_end_timestamp',
            'code',
            'connector',
            'description',
            'taskstatus',
        ]
    }

    export class Vtiger extends Event implements EventInterface {
        data: {
            description: 'test',
            id: '',
            title: '',
            calendar_id: '',
            relations: {},
            date_start: DateConstructor,
            date_start_timestamp: 0,
            date_end: DateConstructor,
            date_end_timestamp: 0,
            code: '',
            connector: 0,
            all_day_event: false,
            taskstatus: '',
            eventstatus: '',
            activitytype: '',
            read_only: false,
        }
    }

    export class Google extends Event implements EventInterface {
        public data: {
            description: 'test',
            id: '',
            title: '',
            calendar_id: '',
            relations: {},
            date_start: DateConstructor,
            date_start_timestamp: 0,
            date_end: DateConstructor,
            date_end_timestamp: 0,
            code: '',
            connector: 0,
            all_day_event: false,
            eventstatus: '',
            taskstatus: '',
            activitytype: '',
            recurrence: '',
            recurrence_period: '',
            guest: '',
            location: '',
            privacy_type: '',
            busyness: '',
            reminder: '',
            reminder_time: '',
            recurrence_preset: '',
            recurrence_period_type: '',
            recurrence_period_end: '',
            recurrence_period_end_date: '',
            recurrence_period_end_after: '',
            recurrence_weekdays: Array<string>,
            read_only: false,
        };

        public publicData = [
            'id',
            'title',
            'calendar_id',
            'date_start_timestamp',
            'date_end_timestamp',
            'code',
            'connector',
            'description',
            'all_day_event',
            'recurrence',
            'recurrence_period',
            'guest',
            'location',
            'privacy_type',
            'busyness',
            'reminder',
            'reminder_time',
            'recurrence_preset',
            'recurrence_period_type',
            'recurrence_period_end',
            'recurrence_period_end_date',
            'recurrence_period_end_after',
            'recurrence_weekdays',
        ];

        public multiple = [
            'recurrence_weekdays'
        ]
    }
}