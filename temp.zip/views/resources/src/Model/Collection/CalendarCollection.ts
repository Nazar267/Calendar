import {Collection} from "../../Core/Model/Collection/Collection";
import {Calendar} from "../Calendar";
import {Event} from "../Event";

export class CalendarCollection extends Collection {

}