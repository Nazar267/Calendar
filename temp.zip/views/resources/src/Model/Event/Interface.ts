export interface EventInterface {
    data: {}

}