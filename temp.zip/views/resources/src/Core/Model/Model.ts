import {ModelInterface} from "./Interface/ModelInterface";
import ObservableObject = kendo.data.ObservableObject;
import {CollectionItemInterface} from "./Collection/Interface/CollectionItemInterface";
import * as _ from "lodash";
import {FlexTranslateInstanceInterface} from "../FlexTranslateInterface";
import {ServiceProvider} from "../ServiceProvider/ServiceProvider";

export abstract class Model implements ModelInterface {

    protected observable: ObservableObject;
    public data = {
        title: '',
        relations: {},
        code: '',
    };

    public multiple: string[] = [];

    public constructor() {
        this.translator = ServiceProvider.getInstance().get('translator') as FlexTranslateInstanceInterface;
    }

    protected element: HTMLElement;
    protected translator: FlexTranslateInstanceInterface;

    public publicData: string[];

    public bindFunctions: {};

    public setBindFunctions() {
        this.bindFunctions = {};
    }

    public setData(data: any) {
        this.data = data;
        return this;
    }

    public getObject() {
        return this;
    }

    public setObservable(element: HTMLElement) {
        this.element = element;
        this.setBindFunctions();
        let _this = this;

        for (let index = 0; index < Object.keys(_this.data).length; index++) {
            let key = Object.keys(_this.data)[index];
            let input = jQuery(element).find("[data-field='" + key + "']");

            input.on('change', function (event) {
                // @ts-ignore
                _this.data[key] = event.target.value;
            });

            if (input.length > 0) {
                _this.addData(key, input.val());
            }
        }

        jQuery(element).find("input, select").each(function (index, element) {
            let field = jQuery(element).data('field');
            _this.addData(field, jQuery(element).val());
        });

        _.forEach(_this.publicData, function (key) {
            let input = jQuery(element).find("[data-field='" + key + "']");
            input.on('change', function (event: any) {
                // @ts-ignore
                _this.data[key] = jQuery(event.target).val();
            });
        });

        this.observable = kendo.observable(
            Object.assign(this.data, this.bindFunctions)
        );
        this.observable.bind("change", function (event: any) {
            let value = event.sender.get(event.field);

            // @ts-ignore
            if (_this.multiple.indexOf(event.field) >= 0) {
                let input = jQuery(element).find("[data-field='" + event.field + "']");
                value = input.val();
            }

            // @ts-ignore
            _this.data[event.field] = value;
        });

        kendo.bind(jQuery(element), this.observable);
    }

    public getObservable() {
        return this.observable;
    }

    public getId() {
        return this.getData('id');
    }

    getData(field: string): any {
        // @ts-ignore
        return this.data[field];
    }

    addData(field: string, value: any): CollectionItemInterface {
        // @ts-ignore
        this.data[field] = value;

        if (typeof field !== 'undefined' && this.getObservable()) this.getObservable().set(field, value);
        return this;
    }

    public getAll(): any {
        let result = {};
        for (let item in this.publicData) {
            // @ts-ignore
            let field = this.publicData[item];

            // @ts-ignore
            if (this.data[field] === null) continue;

            // @ts-ignore
            if (typeof this.data[field] == 'object') {
                // @ts-ignore
                result[field] = this.data[field].toJSON ? this.data[field].toJSON().toString() : this.data[field].toString();
            } else {
                // @ts-ignore
                result[field] = this.data[field];
            }
        }
        return result;
    }
}