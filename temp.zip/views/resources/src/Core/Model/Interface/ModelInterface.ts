import {CollectionItemInterface} from "../Collection/Interface/CollectionItemInterface";

export interface ModelInterface extends CollectionItemInterface {

}