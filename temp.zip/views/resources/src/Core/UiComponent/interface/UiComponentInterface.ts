export interface UiComponentInterface {
    init(): void
}