export class ServiceProviderError extends Error {
}