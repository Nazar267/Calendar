import {ServiceProvider} from "../Core/ServiceProvider/ServiceProvider";
import {MainCalendar} from "../UiComponents/MainCalendar";
import * as moment from 'moment-timezone';

export class DateTime {
    static getSystemDate(date: Date): Date {
        let mainCalendar = ServiceProvider.getInstance().get('mainCalendar') as MainCalendar;

        const allPossibleFormats = [
            'D MMMM YYYY',
            'D MMMM YYYY HH:mm',
            'DD-MM-YY',
            'DD-MM-YYYY HH:mm',
            // 'dd-MM-YYYY HH:mm',
            'DD-MM-YYYY hh:mm A',
            // 'dd-MM-YYYY HH:mm LT',
            'dd-MM-YYYY LT',
            'DD.MM.YYYY',
            'DD.MM.YYYY HH:mm',
            'DD/MM/YY',
            'DD/MM/YYYY',
            'DD/MM/YYYY HH:mm:ss',
            'HH:mm:ss',
            'M/D/YYYY',
            'D/M/YYYY',
            'MM-DD-YY',
            'MM-DD-YYYY HH:mm',
            'MM-DD-YYYY hh:mm A',
            'MM-DD-YYYY',
            'MM-DD-YYYY HH:mm:ss',
            'MM/DD/YY',
            'MM/DD/YYYY',
            'MM/DD/YYYY HH:mm:ss',
            'MMM D YYYY',
            'MMM D YYYY LT',
            'MMMM Do YYYY',
            'MMMM Do YYYY LT',
            'YYYY-DD-MM HH:mm:ss',
            'YYYY-MM',
            'YYYY-MM-DD',
            'YYYY-MM-DD HH:mm',
            'YYYY-MM-DD hh:mm A',
            'YYYY-MM-DD HH:mm:ss',
            'YYYY-MM-DD LT',
            'YYYY-MM-DD h:mm:ss A',
            'YYYY-MM-DDTHH:mm:ssZ',
            'ddd, MMM D YYYY LT',
            'dddd D MMMM YYYY HH:mm',
            'dddd, MMMM Do YYYY LT'
        ];

        // use local time here
        return moment(date, allPossibleFormats, true)
            .tz(mainCalendar.getSystemTimeZone(), true)
            .toDate();
    }

    static getTimestamp(date: Date): number {
        return moment(date).utc(false).valueOf() / 1000;
    }
}
