<?php

namespace RedooCalendar\Source;

use RedooCalendar\Base\Source\BaseSource;

class RecurrenceType extends BaseSource
{
    const data = [
        'Daily' => 'Daily',
        'Weekly' => 'Weekly',
    ];
}