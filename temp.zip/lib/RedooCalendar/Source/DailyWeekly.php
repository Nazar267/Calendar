<?php

namespace RedooCalendar\Source;

use RedooCalendar\Base\Source\BaseSource;

class DailyWeekly extends BaseSource
{
    const data = [
        'daily' => 'Daily',
        'weekly' => 'Weekly',
        'monthly' => 'Monthly',
        'yearly' => 'Yearly',
        'other' => 'Other'
    ];
}