<?php

namespace RedooCalendar\Source;

use RedooCalendar\Base\Source\BaseSource;

class RecurrencePeriodType extends BaseSource
{
    const data = [
        'daily' => 'Days',
        'weekly' => 'Weeks',
        'monthly' => 'Months',
        'yearly' => 'Years'
    ];
}