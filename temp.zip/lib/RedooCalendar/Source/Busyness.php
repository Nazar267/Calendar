<?php

namespace RedooCalendar\Source;

use RedooCalendar\Base\Source\BaseSource;

class Busyness extends BaseSource
{
    const data = [
        'opaque' => 'Busy',
        'transparent' => 'Free'
    ];
}