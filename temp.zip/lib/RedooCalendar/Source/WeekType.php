<?php

namespace RedooCalendar\Source;

use RedooCalendar\Base\Source\BaseSource;

class WeekType extends BaseSource
{
    const data = [
        'MO' => 'Monday',
        'TU' => 'Tuesday',
        'WE' => 'Wednesday',
        'TH' => 'Thursday',
        'FR' => 'Friday',
        'SA' => 'Saturday',
        'SU' => 'Sunday',
    ];
}