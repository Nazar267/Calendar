<?php

namespace RedooCalendar\Source;

use RedooCalendar\Base\Source\BaseSource;

class Reminder extends BaseSource
{
    const data = [
        'Notification' => 'Notification',
        'Message_On_Email' => 'Message on e-mail'
    ];
}