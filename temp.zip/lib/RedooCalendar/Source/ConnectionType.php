<?php

namespace RedooCalendar\Source;

use RedooCalendar\Base\Source\BaseSource;

class ConnectionType extends BaseSource
{
    const data = [
        'google' => 'Google Calendar',
    ];
}