<?php

namespace RedooCalendar\Source;

use RedooCalendar\Base\Source\BaseSource;

class RecurrenceEnd extends BaseSource
{
    const data = [
        'never' => 'Newer',
        'date' => 'Date',
        'after' => 'After',
    ];
}