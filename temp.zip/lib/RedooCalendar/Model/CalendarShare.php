<?php


namespace RedooCalendar\Model;


use RedooCalendar\Base\Model\BaseModel;

class CalendarShare extends BaseModel
{
    static $_tableName = 'calendar_share';

}