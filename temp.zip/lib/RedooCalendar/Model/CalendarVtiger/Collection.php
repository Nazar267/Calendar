<?php

namespace RedooCalendar\Model\CalendarVtiger;

use RedooCalendar\Base\Collection\BaseExternalCollection;

/**
 * VtigerCalendarCollection
 * @package RedooCalendar\Model\CalendarVtiger
 */
class Collection extends BaseExternalCollection
{

}