<?php


namespace RedooCalendar\Model\Connection;


use RedooCalendar\Base\Collection\BaseCollection;
use RedooCalendar\Model\Connection;

class Collection extends BaseCollection
{
    protected $model = Connection::class;
}