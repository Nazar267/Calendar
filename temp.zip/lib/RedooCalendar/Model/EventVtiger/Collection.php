<?php

namespace RedooCalendar\Model\EventVtiger;

use RedooCalendar\Base\Collection\BaseExternalCollection;

/**
 * EventVtigerCollection
 * @package RedooCalendar\Model\EventVtiger
 */
class Collection extends BaseExternalCollection
{

}