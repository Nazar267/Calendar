<?php

namespace RedooCalendar\Model;

use RedooCalendar\Base\Model\BaseModel;

class CalendarPermission extends BaseModel
{
    static $_tableName = 'calendar_permission';

    /**
     * Fetch by calendar and user
     *
     * @param string $calendarId
     * @param int $connectionId
     * @return BaseModel
     */
    public function fetchByCalendarId(string $calendarId): BaseModel
    {

        $data = $this->_table->fetchRows([
            'calendar_id = \'' . $calendarId . '\'',
        ]);
        if (isset($data[0])) {
            $this->setData($data[0]);
        }

        return $this;
    }
}
