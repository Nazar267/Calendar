<?php

namespace RedooCalendar\Model\EventGoogle;

use RedooCalendar\Base\Collection\BaseExternalCollection;

/**
 * EventGoogleCollection
 * @package RedooCalendar\Model\EventGoogle
 */
class Collection extends BaseExternalCollection
{

}