<?php

namespace RedooCalendar\Model\Base;

/**
 * Base EventInterface
 * @package RedooCalendar\Model\Base
 */
interface EventInterface
{
    function delete();
}