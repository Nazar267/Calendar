<?php

namespace RedooCalendar\Model\Base\CalendarInterface;

/**
 * Base Collection Interface
 * @package RedooCalendar\Model\Base\CalendarInterface
 */
interface Collection
{

}