<?php

namespace RedooCalendar\Model\Base;

use RedooCalendar\Base\Collection\Item\CollectionItemInterface;

/**
 * Base CalendarInterface
 * @package RedooCalendar\Model\Base
 */
interface CalendarInterface extends CollectionItemInterface
{
    public function save();
    public function delete(): bool;
}