<?php

namespace RedooCalendar\Model;

use RedooCalendar\Base\Form\Validator\DateTime;
use RedooCalendar\Base\Model\BaseExternalModel;
use RedooCalendar\Model\Base\EventInterface;
use RedooCalendar\Model\EventGoogle\Collection as EventGoogleCollection;
use RedooCalendar\Model\EventVtiger\Collection as EventVtigerCollection;

class EventGoogle extends BaseExternalModel implements EventInterface
{
    protected $apiClient;
    protected $service;
    protected $collection = EventGoogleCollection::class;

    public function __construct(\Google_Client $apiClient = null)
    {
        if ($apiClient) {
            $this->apiClient = $apiClient;
            $this->service = new \Google_Service_Calendar($this->apiClient);
            parent::__construct();
        }
    }


    /**
     * Save model
     *
     * @return CalendarGoogle
     * @throws \Exception
     */
    public function save(): EventGoogle
    {
        if ($this->service) {
            $event = new \Google_Service_Calendar_Event();
            $event->setSummary($this->getTitle());


            if ($this->getAllDayEvent()) {
                $startDate = new \DateTime($this->getDateStart());
                $endDate = new \DateTime($this->getDateEnd());

                $start = new \Google_Service_Calendar_EventDateTime();
                $start->setDate($startDate->format('yy-m-d'));

                $end = new \Google_Service_Calendar_EventDateTime();
                $end->setDate($endDate->format('yy-m-d'));
            } else {
                $start = new \Google_Service_Calendar_EventDateTime();
                $start->setDateTime($this->getDateStart());
                $start->setTimeZone('UTC');

                $end = new \Google_Service_Calendar_EventDateTime();
                $end->setDateTime($this->getDateEnd());
                $end->setTimeZone('UTC');

            }

            $event->setStart($start);
            $event->setEnd($end);

            //TODO CHANGE THIS
            if ($this->getRecurrence() == 'yes') {
                switch ($this->getRecurrencePreset()) {
                    case 'daily':
                        $event->setRecurrence(array('RRULE:FREQ=DAILY'));
                        break;
                    case 'weekly':
                        $event->setRecurrence(array('RRULE:FREQ=WEEKLY'));
                        break;
                    case 'monthly':
                        $event->setRecurrence(array('RRULE:FREQ=MONTHLY'));
                        break;
                    case 'yearly':
                        $event->setRecurrence(array('RRULE:FREQ=YEARLY'));
                        break;
                    case 'other':
                        $periodType = $this->getRecurrencePeriodType();
                        $period = $this->getRecurrencePeriod();

                        $stop = '';
                        switch ($this->getRecurrencePeriodEnd()) {
                            case 'date':
                                $date = new \DateTime($this->getRecurrencePeriodEndDate());
                                $stop = 'UNTIL=' . $date->format('Ymd') . ';';
                                break;
                            case 'after':
                                $stop = 'COUNT=' . $this->getRecurrencePeriodEndAfter() . ';';
                                break;
                        }

                        if($this->getRecurrenceWeekdays()) {
                            $weekDays = 'BYDAY=' . $this->getRecurrenceWeekdays() . ';';
                        } else {
                            $weekDays = '';
                        }
                        $event->setRecurrence(array('RRULE:FREQ=' . strtoupper($periodType) . ';' . $stop . 'INTERVAL=' . $period . ';' . $weekDays));
                        break;
                }

            }

//            var_dump($this->getGuest());
//            $attendees = explode(', ', $this->getGuest());
//var_dump($attendees);
//die();
//            $_attendees = [];
//            foreach ($attendees as $attendee) {
//                $_attendee = new \Google_Service_Calendar_EventAttendee();
//                $_attendee->email = trim($attendee);
//                $_attendees[] = $_attendee;
//            }
//
//
//            $event->setAttendees($_attendees);

            $event->setLocation($this->getLocation());
            $event->setDescription($this->getDescription());
//            $event->setVisibility($this->getVisibility());
//            $event->setTransparency($this->getBusyness());

            $event->setHangoutLink('');

            $reminder = new \Google_Service_Calendar_EventReminders();

            $reminder->setUseDefault("false");
            $reminder->setOverrides(array(
                array(
                    "method" => "popup",
                    "minutes" => 300
                )
            ));

            $event->setReminders($reminder);


            $createdEvent = $this->service->events->insert($this->getCalendarId(), $event);

            $this->setId($createdEvent->getId());
        } else {
            throw new \Exception('Api Client not provided');
        }
        return $this;
    }

    public function update(): EventGoogle
    {
        if ($this->service) {

            $event = $this->service->events->get($this->getData('calendar_id'), $this->getId());

            $event->setSummary($this->getTitle());
            $event->setId($this->getId());

            if ($this->getAllDayEvent() ) {
                $startDate = new \DateTime($this->getDateStart());
                $endDate = new \DateTime($this->getDateEnd());

                $start = new \Google_Service_Calendar_EventDateTime();
                $start->setDate($startDate->format('yy-m-d'));

                $end = new \Google_Service_Calendar_EventDateTime();
                $end->setDate($endDate->format('yy-m-d'));
            } else {
                $start = new \Google_Service_Calendar_EventDateTime();
                $start->setDateTime($this->getDateStart());
                $start->setTimeZone('UTC');

                $end = new \Google_Service_Calendar_EventDateTime();
                $end->setDateTime($this->getDateEnd());
                $end->setTimeZone('UTC');

            }

            $event->setStart($start);
            $event->setEnd($end);

            //TODO CHANGE THIS
            if ($this->getRecurrence() == 'yes') {

                switch ($this->getRecurrencePreset()) {
                    case 'daily':
                        $event->setRecurrence(array('RRULE:FREQ=DAILY'));
                        break;
                    case 'weekly':
                        $event->setRecurrence(array('RRULE:FREQ=WEEKLY'));
                        break;
                    case 'monthly':
                        $event->setRecurrence(array('RRULE:FREQ=MONTHLY'));
                        break;
                    case 'yearly':
                        $event->setRecurrence(array('RRULE:FREQ=YEARLY'));
                        break;
                    case 'other':
                        $periodType = $this->getRecurrencePeriodType();
                        $period = $this->getRecurrencePeriod();

                        $stop = '';
                        switch ($this->getRecurrencePeriodEnd()) {
                            case 'date':
                                $date = new \DateTime($this->getRecurrencePeriodEndDate());
                                $stop = 'UNTIL=' . $date->format('Ymd') . ';';
                                break;
                            case 'after':
                                $stop = 'COUNT=' . $this->getRecurrencePeriodEndAfter() . ';';
                                break;
                        }

                        $weekDays = 'BYDAY=' . $this->getRecurrenceWeekdays() . ';';

                        $event->setRecurrence(array('RRULE:FREQ=' . strtoupper($periodType) . ';' . $stop . 'INTERVAL=' . $period . ';' . $weekDays));
                        break;
                }

            } elseif ($this->getRecurrence() == 'no') {
                $event->setRecurrence([]);
            }

            $event->setDescription($this->getDescription());

            $createdEvent = $this->service->events->update($this->getCalendarId(), $this->getId(), $event);

            $this->setId($createdEvent->getId());
        } else {
            throw new \Exception('Api Client not provided');
        }
        return $this;
    }

    function delete()
    {
        if ($this->service) {
            $this->service->events->delete($this->getCalendarId(), $this->getId());
            return true;
        }
        return false;
    }
}