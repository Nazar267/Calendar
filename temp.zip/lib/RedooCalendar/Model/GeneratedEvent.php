<?php

namespace RedooCalendar\Model;

use RedooCalendar\Base\Model\BaseExternalModel;

use RedooCalendar\Model\Base\EventInterface;

class GeneratedEvent extends BaseExternalModel implements EventInterface
{

}