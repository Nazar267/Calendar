<?php

namespace RedooCalendar\Base\Exception;

/**
 * Class RelationException
 * @package RedooCalendar\Base\Exception
 */
class RelationException extends \Exception
{

}