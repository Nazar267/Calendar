<?php

namespace RedooCalendar\Base\Exception;

/**
 * Class DatabaseException
 * @package RedooCalendar\Base\Exception
 */
class DatabaseException extends \Exception
{

}