<?php


namespace RedooCalendar\Base\Form;


class Validator
{
    function isValid($completeValues) {

    }
}
