<?php

namespace RedooCalendar\Base\Form\Validator;

use RedooCalendar\Base\Form\Base\Validator;

class Number extends Validator
{

    protected $regex = '^[0-9]*$';
    protected $errorText = 'Only numbers';

    function isValid($value)
    {
        if(empty($value)) {
            throw new \Exception( $this->errorText);
        }
    }

    function generateValidateJsData()
    {
        $data = array(
            'format' => array(
                'pattern' => $this->regex,
                'message' => $this->errorText
            )
        );

        return $data;
    }
}
