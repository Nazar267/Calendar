<?php

namespace RedooCalendar\Base\Form\Validator;
use RedooCalendar\Base\Form\Base\Validator;

class Email extends Validator
{
//    public function
}
