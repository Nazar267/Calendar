<?php


namespace RedooCalendar\Base\Form\Validator;

class URL extends \RedooCalendar\Base\Validator
{

}
