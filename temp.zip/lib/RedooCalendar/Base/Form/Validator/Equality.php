<?php


namespace RedooCalendar\Base\Form\Validator;
use RedooCalendar\Base\Form\Base\Validator;

class Equality extends Validator
{

    function isValid($value)
    {
        // TODO: Implement isValid() method.
    }

    function generateValidateJsData()
    {
        // TODO: Implement generateValidateJsData() method.
    }
}
