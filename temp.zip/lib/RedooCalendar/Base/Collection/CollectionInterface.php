<?php


namespace RedooCalendar\Base\Collection;


interface CollectionInterface
{
    public function getItemsAsArray(): array;
}