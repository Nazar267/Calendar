<?php


namespace RedooCalendar\Base\Source;


use RedooCalendar\Helper\Translator;

abstract class BaseSource implements SourceInterface
{
    use Translator;

    const data = [];

    /**
     * @param bool $translate
     * @return array
     */
    public static function getData(bool $translate = true): array
    {
        if ($translate) {
            foreach (static::data as $key => &$value) {
                $value = self::t($value);
            }
        }

        return static::data;
    }

    /**
     * @param bool $translate
     * @return array
     */
    public static function getOptionsData(bool $translate = true): array
    {
        if ($translate) {
            foreach (static::data as $key => &$value) {
                $value = self::t($value);
            }
        }

        return array_merge(
            [
                null => self::t('Select Option')
            ],
            static::data
        );
    }

    public static function getKeys(): array
    {
        return array_keys(static::data);
    }

    public function __get($name)
    {
        return static::$name();
    }
}