<?php


namespace RedooCalendar\Base\View;


use RedooCalendar\Base\Connection\Connection;
use RedooCalendar\Base\Connection\ConnectorPlugin\ConnectorPluginInterface;
use RedooCalendar\Helper\Translator;

class BaseView extends \Vtiger_Index_View
{
    use Translator;

    protected $user;
    protected $connector;

    public function __construct()
    {
        $this->user = \Users_Record_Model::getCurrentUserModel();
        parent::__construct();
    }


    /**
     * Get external calendar connector
     *
     * @return ConnectorPluginInterface
     * @throws \Exception
     */
    protected function getConnector(): ConnectorPluginInterface
    {
        if (!$this->connector) {
            $request = new \Vtiger_Request($_REQUEST);
            if ($request->has('connector')) {
                $this->connector = Connection::GetInstance($request->get('connector'))->getConnector();
            } else {
                throw new \Exception('Connector not provided in request');
            }
        }
        return $this->connector;
    }

    public function getUser(): \Users_Record_Model
    {
        return $this->user;
    }

    protected function getDocumentation(\Vtiger_Request $request)
    {
        $moduleName = $request->getModule();
        $moduleModel = \Vtiger_Module_Model::getInstance($moduleName);
        $viewer = $this->getViewer($request);

        $adb = \PearDatabase::getInstance();

        $localVersion = $adb->pquery('select version from vtiger_redoodocumentation_to_user  where module = ? and user_id = ? and view = ? order by id desc  limit 1 ', [
            $moduleName, \Users_Record_Model::getCurrentUserModel()->getId(), $request->get('view')
        ]);
        $template = $moduleModel::DOCUMENTATION_URL .
            'shorturl.php?id=redoodocumentationtemplate' .
            '&module=' . $moduleModel->getName() .
            '&version=' . $moduleModel->version .
            '&subscription=pro' .
            '&language=' . \Vtiger_Language_Handler::getLanguage() .
            '&view=' . $request->get('view');

        $version = $moduleModel::DOCUMENTATION_URL .
            'shorturl.php?id=redoodocumentationversion' .
            '&module=' . $moduleModel->getName() .
            '&version=' . $moduleModel->version .
            '&subscription=pro' .
            '&language=' . \Vtiger_Language_Handler::getLanguage() .
            '&view=' . $request->get('view');

        $companyDetails = $moduleModel::DOCUMENTATION_URL .
            'shorturl.php?id=redoodocumentationcompany';

        $version = file_get_contents($version);

        if ($localVersion->fields == false && $version) {

            $result = $adb->pquery('insert into vtiger_redoodocumentation_to_user (user_id, module, version, view) values (?, ?, ?, ?)', [
                \Users_Record_Model::getCurrentUserModel()->getId(), $moduleName, $version, $request->get('view')
            ]);

            $viewer->assign('documentationLink', $template);
            $viewer->assign('documentation', true);
        } elseif ($localVersion->fields != false && $version) {

            if ((float)$localVersion->fields['version'] < (float)$version) {

                $adb->pquery('insert into vtiger_redoodocumentation_to_user (user_id, module, version, view) values (?, ?, ?, ?)', [
                    \Users_Record_Model::getCurrentUserModel()->getId(), $moduleName, $version, $request->get('view')
                ]);

                $viewer->assign('documentationLink', $template);
                $viewer->assign('documentation', true);
            } else {
                $viewer->assign('documentation', false);
            }

        }


        $viewer->assign('companyDetails', json_decode(file_get_contents($companyDetails), 1));
        $viewer->assign('documentationUrl', $moduleModel::DOCUMENTATION_URL);
    }
}