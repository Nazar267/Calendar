<?php

namespace RedooCalendar\Helper;

class OAuth
{
    public static function getInternalCallbackUrl($currentHash)
    {
        $adb = \PearDatabase::getInstance();
        $moduleName = 'RedooCalendar';

        $sql = 'SELECT * FROM vtiger_shorturls WHERE handler_class = "' . $moduleName . '_OAuthHTTPHandler_Handler" LIMIT 1';
        $result = $adb->query($sql);

        if ($adb->num_rows($result) == 0) {
            $options = array(
                'handler_path' => 'modules/' . $moduleName . '/actions/GoogleOAuthHTTPHandler.php',
                'handler_class' => $moduleName . '_GoogleOAuthHTTPHandler',
                'handler_function' => 'handle',
                'handler_data' => array()
            );

            $uid = \Vtiger_ShortURL_Helper::generate($options);
            $callbackUrl = rtrim(vglobal('site_URL'), '/') . "/shorturl.php?id=" . $uid . (!empty($currentHash) ? '&_h=' . $currentHash : '');
        } else {
            $callbackUrl = rtrim(vglobal('site_URL'), '/') . "/shorturl.php?id=" . $adb->query_result($result, 0, 'uid') . (!empty($currentHash) ? '&_h=' . $currentHash : '');
        }

        return $callbackUrl;
    }

}