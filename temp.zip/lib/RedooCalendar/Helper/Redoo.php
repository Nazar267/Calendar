<?php


namespace RedooCalendar\Helper;


class Redoo
{
    public static function underscoreToCamelCase($string, $capitalizeFirstCharacter = false)
    {
        $str = str_replace(' ', '', ucwords(str_replace('_', ' ', $string)));

        if (!$capitalizeFirstCharacter) {
            $str[0] = strtolower($str[0]);
        }

        return $str;
    }

    public static function getTimeFormat($formatText): string
    {
        $format = 'HH:mm';

        if ($formatText === '12') {
            $format = 'hh:mm tt' ;
        }

        return $format;
    }
}