<?php
namespace ComplexCondition\Form\Validator;
use ComplexCondition\Form\Base\Validator;

class Number extends Validator
{

}
