<?php


namespace ComplexCondition\Form\Validator;

class URL extends \ComplexCondition\Base\Validator
{

}
