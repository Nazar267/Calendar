<?php

namespace ComplexCondition\Form\Validator;
use ComplexCondition\Form\Base\Validator;

class Email extends Validator
{
//    public function
}
