<?php


namespace ComplexCondition\Form\Validator;
use ComplexCondition\Form\Base\Validator;

class Equality extends Validator
{

    function isValid($value)
    {
        // TODO: Implement isValid() method.
    }

    function generateValidateJsData()
    {
        // TODO: Implement generateValidateJsData() method.
    }
}
