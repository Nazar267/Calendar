<?php


namespace ComplexCondition\Form;


class Validator
{
    function isValid($completeValues) {

    }
}
