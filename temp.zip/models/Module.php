<?php


class RedooCalendar_Module_Model extends Vtiger_Module_Model
{
    const DOCUMENTATION_URL = 'https://beta.redoo-ukraine.space/';
}

