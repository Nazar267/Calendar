<?php

namespace RedooCalendar\ConnectorPlugins;

use DateTime;
use DateTimeZone;
use RedooCalendar\Base\Collection\BaseExternalCollection;
use RedooCalendar\Base\Collection\CollectionInterface;
use RedooCalendar\Base\Connection\ConnectorPlugin;
use RedooCalendar\Base\Form\Field;
use RedooCalendar\Base\Form\Group;
use RedooCalendar\Base\Form\Validator\Length;
use RedooCalendar\Base\Form\Validator\Mandatory;
use RedooCalendar\Base\Form\Validator\Number;
use RedooCalendar\Model\Base\CalendarInterface;
use RedooCalendar\Model\Base\EventInterface;
use RedooCalendar\Model\Calendar;
use RedooCalendar\Model\CalendarGoogle;
use RedooCalendar\Model\CalendarGoogle\Collection as CalendarGoogleCollection;
use RedooCalendar\Model\Connection;
use RedooCalendar\Model\Event;
use RedooCalendar\Model\EventGoogle;
use RedooCalendar\Model\Subscribe;
use RedooCalendar\Model\Subscribe\Collection as SubscribeCollection;
use RedooCalendar\Helper\OAuth;
use RedooCalendar\Source\Busyness;
use RedooCalendar\Source\DailyWeekly;
use RedooCalendar\Source\RecurrenceEnd;
use RedooCalendar\Source\RecurrencePeriodType;
use RedooCalendar\Source\Reminder;
use RedooCalendar\Source\WeekType;

class Google extends ConnectorPlugin
{
    protected $apiClient;
    protected $allDaySupport = true;

    protected $eventConfig = [
        'event' => [
            'model' => 'Google',
            'headline' => 'Event',
            'blocks' => [
                'general' => [
                    'column_count' => 1,
                    'headline' => 'General',
                    'fields' => [
                        'title' => [
                            'headline' => 'Event Title',
                            'name' => 'title',
                            'type' => Field::INPUT_TEXT,
                            'validator' => Mandatory::class
                        ],
                    ]
                ],
                'date_time' => [
                    'column_count' => 3,
                    'headline' => 'Date and time',
                    'fields' => [
                        'all_day_event' => [
                            'headline' => 'All Day Event',
                            'name' => 'all_day_event',
                            'type' => Field::INPUT_PICKLIST,
                            'options' => [
                                'options' => ['no' => 'No', 'yes' => 'Yes']
                            ]
                        ],
                        'date_start' => [
                            'headline' => 'Date Start',
                            'name' => 'date_start',
                            'type' => Field::INPUT_DATE_TIME_PICKER,
                            'validator' => Mandatory::class,
                        ],
                        'date_end' => [
                            'headline' => 'Date End',
                            'name' => 'date_end',
                            'type' => Field::INPUT_DATE_TIME_PICKER,
                            'validator' => Mandatory::class,
                        ],
                    ]
                ],
                'recurrence' => [
                    'column_count' => 2,
                    'headline' => 'Recurrence',
                    'fields' => [
                        'recurrence' => [
                            'headline' => 'Recurrence',
                            'name' => 'recurrence',
                            'type' => Field::INPUT_PICKLIST,
                            'options' => [
                                'options' => ['no' => 'No', 'yes' => 'Yes']
                            ],
                        ],
                        'recurrence_preset' => [
                            'headline' => 'Preset',
                            'name' => 'recurrence_preset',
                            'type' => Field::INPUT_PICKLIST,
                            'options' => [
                                'options' => DailyWeekly::data
                            ],
                            'validator' => Mandatory::class,
                            'related' => ['recurrence' => ['yes']],
                        ],
                        'recurrence_period' => [
                            'headline' => 'Period',
                            'name' => 'recurrence_period',
                            'type' => Field::INPUT_TEXT,
                            'validator' => Number::class,
                            'related' => ['recurrence_preset' => ['other'], 'recurrence' => ['yes']],
                        ],
                        'recurrence_period_type' => [
                            'headline' => 'Period Type',
                            'name' => 'recurrence_period_type',
                            'type' => Field::INPUT_PICKLIST,
                            'options' => [
                                'options' => RecurrencePeriodType::data
                            ],
                            'related' => ['recurrence_preset' => ['other'], 'recurrence' => ['yes']],
                        ],
                        'recurrence_weekdays' => [
                            'headline' => 'Weekdays',
                            'name' => 'recurrence_weekdays',
                            'type' => Field::INPUT_PICKLIST,
                            'options' => [
                                'options' => WeekType::data,
                                'multiple' => true,
                            ],
                            'related' => ['recurrence_preset' => ['other'], 'recurrence_period_type' => ['weekly'], 'recurrence' => ['yes']],
                        ],
                        'recurrence_period_end' => [
                            'headline' => 'Repetition end',
                            'name' => 'recurrence_period_end',
                            'type' => Field::INPUT_PICKLIST,
                            'options' => [
                                'options' => RecurrenceEnd::data
                            ],
                            'related' => ['recurrence_preset' => ['other'], 'recurrence' => ['yes']],
                        ],
                        'recurrence_period_end_date' => [
                            'headline' => 'Repetition end date',
                            'name' => 'recurrence_period_end_date',
                            'type' => Field::INPUT_DATE_TIME_PICKER,
                            'related' => ['recurrence_period_end' => ['date'], 'recurrence_preset' => ['other'], 'recurrence' => ['yes']],
                        ],
                        'recurrence_period_end_after' => [
                            'headline' => 'Repetition end after iterations',
                            'name' => 'recurrence_period_end_after',
                            'type' => Field::INPUT_TEXT,
                            'related' => ['recurrence_period_end' => ['after'], 'recurrence_preset' => ['other'], 'recurrence' => ['yes']],
                        ],
                    ]
                ],
                //'time_zone' => [
                //  'column_count' => 1,
                //  'headline' => 'Time Zone',
                //    'fields' => [
                //        'title' => [
                //            'headline' => 'Choose Time Zone',
                //            'name' => 'time_zone',
                //            'type' => Field::INPUT_PICKLIST,
                //            'validator' => Mandatory::class
                //        ]
                //    ]
                //],
//                'guests' => [
//                    'column_count' => 1,
//                    'headline' => 'Guests',
//                    'fields' => [
//                        'title' => [
//                            'headline' => 'Add a guest',
//                            'name' => 'guest',
//                            'type' => Field::INPUT_PICKLIST,
//                            'options' => [
//                                'multiple' => true,
//                                'tags' => true,
//                                'sortable' => true
//                            ]
//                        ],
//                    ]
//                ],
//                'place_or_conference' => [
//                    'column_count' => 2,
//                    'headline' => 'Add a place or conference',
//                    'fields' => [
//                        'place' => [
//                            'headline' => 'Set Location',
//                            'name' => 'location',
//                            'type' => Field::INPUT_TEXT,
//                        ],
//                        'conference' => [
//                            'headline' => 'Add Video Conference',
//                            'name' => 'conference',
//                            'type' => Field::INPUT_PICKLIST,
//                            'options' => [
//                                'options' => [0 => 'No', 1 => 'Hangouts']
//                            ]
//                        ],
//                    ]
//                ],
                'content' => [
                    'column_count' => 1,
                    'headline' => 'Content',
                    'fields' => [
                        'description' => [
                            'headline' => 'Event Description',
                            'name' => 'description',
                            'type' => Field::INPUT_TEXT,
                        ],
                    ]
                ],
//                'reminder' => [
//                    'column_count' => 4,
//                    'headline' => 'Reminder',
//                    'fields' => [
//                        'reminder' => [
//                            'headline' => 'Method',
//                            'name' => 'reminder',
//                            'type' => Field::INPUT_PICKLIST,
//                            'options' => [
//                                'options' => Reminder::data
//                            ]
//                        ],
//                        'reminder_time' => [
//                            'headline' => 'Minutes',
//                            'name' => 'reminder_time',
//                            'type' => Field::INPUT_TEXT,
//                        ]
//                    ]
//                ],
//                'busyness' => [
//                    'column_count' => 1,
//                    'headline' => 'Busyness',
//                    'fields' => [
//                        'title' => [
//                            'headline' => 'Busy/Free',
//                            'name' => 'busyness',
//                            'type' => Field::INPUT_PICKLIST,
//                            'options' => [
//                                'options' => Busyness::data
//                            ]
//                        ],
//                    ]
//                ],
//                'privacy' => [
//                    'column_count' => 2,
//                    'headline' => '',
//                    'fields' => [
//                        'privacy_type' => [
//                            'headline' => 'Privacy',
//                            'name' => 'privacy_type',
//                            'type' => Field::INPUT_PICKLIST,
//                            'options' => [
//                                'options' => ['public' => 'Public', 'private' => 'Private']
//                            ]
//                        ]
//                    ]
//                ],
            ]
        ],
//        'task' => [
//            'model' => 'RedooTask',
//            'headline' => 'Task',
//            'blocks' => [
//                'general' => [
//                    'column_count' => 1,
//                    'headline' => 'General',
//                    'fields' => [
//                        'title' => [
//                            'headline' => 'Task Title',
//                            'name' => 'title',
//                            'type' => Field::INPUT_TEXT,
//                            'validator' => Mandatory::class
//                        ],
//                    ]
//                ],
//                'date_time' => [
//                    'column_count' => 2,
//                    'headline' => 'Date and time',
//                    'fields' => [
//                        'date_start' => [
//                            'headline' => 'Date Start',
//                            'name' => 'date_start',
//                            'type' => Field::INPUT_DATE_TIME_PICKER,
//                            'validator' => Mandatory::class
//                        ],
//                        'date_end' => [
//                            'headline' => 'Date End',
//                            'name' => 'date_end',
//                            'type' => Field::INPUT_DATE_TIME_PICKER, 'validator' => Mandatory::class
//                        ],
//                    ]
//                ],
//                'content' => [
//                    'column_count' => 1,
//                    'headline' => 'Content',
//                    'fields' => [
//                        'title' => [
//                            'headline' => 'Task Description',
//                            'name' => 'description',
//                            'type' => Field::INPUT_TEXT,
//                            'validator' => Mandatory::class
//                        ],
//                    ]
//                ],
//            ]
//        ],
    ];

    public function getEventModel(): string
    {
        return 'GoogleEvent';
    }

    public function __construct($settings)
    {
        parent::__construct($settings);
    }

    /**
     * Get google api client
     *
     * @param bool $redirect
     * @return Google
     * @throws \Google_Exception
     */
    public function getApiClient(bool $redirect = false): Google
    {
        global $site_URL;

        $googleConnection = new Connection();
        $googleConnection->fetchByCode($this->data['code']);
        $settings = json_decode(html_entity_decode($googleConnection->getSettings()), true);

        $apiClient = new \Google_Client();
        $apiClient->setApplicationName('Google Calendar API PHP Quickstart');
        $apiClient->setAuthConfig(array(
            'web' =>
                array(
                    'client_id' => '400699107646-ft6okl28b9d5mhljada5cga1t04la557.apps.googleusercontent.com',
                    'project_id' => 'redoo-ua',
                    'auth_uri' => 'https://accounts.google.com/o/oauth2/auth',
                    'token_uri' => 'https://oauth2.googleapis.com/token',
                    'auth_provider_x509_cert_url' => 'https://www.googleapis.com/oauth2/v1/certs',
                    'client_secret' => '8tv1soKK1_dmqVFnCCvVG84L',
                    'redirect_uris' =>
                        array(
                            0 => $site_URL . 'shorturl.php?id=redoo.calendar',
                        ),
                ),
        ));
        $apiClient->setAccessType('offline');
        $apiClient->setPrompt('select_account consent');
        $apiClient->setScopes(\Google_Service_Calendar::CALENDAR);

        if (isset($settings['token'])) {
            $apiClient->setAccessToken($settings['token']);
        }

        if (isset($settings['access_token'])) {
            if ($apiClient->isAccessTokenExpired()) {
                if ($apiClient->getRefreshToken()) {
                    $apiClient->fetchAccessTokenWithRefreshToken($apiClient->getRefreshToken());
                } else {

                    $accessToken = $apiClient->fetchAccessTokenWithAuthCode($settings['access_token']);
                    $apiClient->setAccessToken($accessToken);

                    $googleConnection->setSettings(
                        json_encode(
                            array_merge(['token' => $accessToken], $settings)
                        )
                    );

                    $googleConnection->save();

                }

            }
            $this->apiClient = $apiClient;
        }

        return $this;
    }

    public function getRedirectUrl(): string
    {
        $apiClient = new \Google_Client();
        $apiClient->setApplicationName('Redoo Calendar');

        global $site_URL;

        $apiClient->setAuthConfig(array(
            'web' =>
                array(
                    'client_id' => '400699107646-ft6okl28b9d5mhljada5cga1t04la557.apps.googleusercontent.com',
                    'project_id' => 'redoo-ua',
                    'auth_uri' => 'https://accounts.google.com/o/oauth2/auth',
                    'token_uri' => 'https://oauth2.googleapis.com/token',
                    'auth_provider_x509_cert_url' => 'https://www.googleapis.com/oauth2/v1/certs',
                    'client_secret' => '8tv1soKK1_dmqVFnCCvVG84L',
                    'redirect_uris' =>
                        array(
                            0 => $site_URL . 'shorturl.php?id=redoo.calendar'
                        ),
                ),
        ));


        $apiClient->setState(json_encode([
            'connection_id' => $this->data['id'],
            'back_url' => $site_URL
        ]));

        $apiClient->setAccessType('offline');
        $apiClient->setPrompt('select_account consent');
        $apiClient->setScopes(\Google_Service_Calendar::CALENDAR);


        return $apiClient->createAuthUrl();
    }

    public function getSubscribedCalendarCollection(): array
    {
        $subscribeCollection = new SubscribeCollection();
        $subscribeCollection->fetch([
            [
                'column' => 'connection_id',
                'value' => $this->getId()
            ]
        ]);

        $collection = $this->getCalendarCollection();

        /** @var Subscribe $item */
        foreach ($subscribeCollection->getItems() as $item) {
            if ($calendar = $collection->getItem($item->getCalendarId())) {
                $calendar->setColor($item->getColor());
                $calendar->setVisible($item->getVisible());
            }
        }

        return array_values(array_filter($collection->getItemsAsArray(), function ($item) use ($subscribeCollection) {
            return in_array($item['id'], $subscribeCollection->getCalendarIds());
        }));

    }

    public function initEvents(CalendarInterface &$calendar): self
    {
        $this->getApiClient();
        $timezone = $this->getUserTimeZone();
        if ($this->apiClient) {

            $calendarService = new \Google_Service_Calendar($this->apiClient);
            /** @var \Google_Service_Calendar_Event $_event */
            foreach ($calendarService->events->listEvents($calendar->getId(), ['maxResults' => 2500]) as $_event) {

                if ($_event->getStart() && $_event->getEnd()) {

                    $event = new EventGoogle();

                    if ($_event->getStart()->getDateTime() == null) {
                        $event->setAllDayEvent(true);

                        $event->setDateStart(
                            (new \DateTime($_event->getStart()->getDate()))
                                ->setTimezone($timezone)
                                ->format('Y-m-d H:i:s'));
                        $event->setDateEnd(
                            (new \DateTime($_event->getEnd()->getDate()))
                                ->setTimezone($timezone)
                                ->format('Y-m-d H:i:s'));
                    } else {
                        $event->setDateStart(
                            (new \DateTime($_event->getStart()->getDateTime()))
                                ->setTimezone($timezone)
                                ->format('Y-m-d H:i:s'));
                        $event->setDateEnd(
                            (new \DateTime($_event->getEnd()->getDateTime()))
                                ->setTimezone($timezone)
                                ->format('Y-m-d H:i:s'));
                    }


                    $event->setId($_event->getId());
                    $event->setCalendarId($calendar->getId());
                    $event->setTitle($_event->getSummary());

                    $event->setConnector($this->getId());

                    $calendar->setEvent($event);

                    $eventId = $event->getId();
                    if ($_event->getRecurrence()) {
                        foreach ($_event->getRecurrence() as $recurrence) {

                            $iterations = 31;
                            // "RRULE:FREQ=WEEKLY;INTERVAL=2;BYDAY=SA,SU;COUNT=2"
                            preg_match_all('/COUNT=([a-zA-Z0-9]+)/m', $recurrence, $iterationsMatches, PREG_SET_ORDER, 0);
                            preg_match_all('/FREQ=([a-zA-Z0-9]+)/m', $recurrence, $freqMatches, PREG_SET_ORDER, 0);
                            preg_match_all('/INTERVAL=([a-zA-Z0-9]+)/m', $recurrence, $intervalMatches, PREG_SET_ORDER, 0);
                            preg_match_all('/UNTIL=([a-zA-Z0-9]+)/m', $recurrence, $untilMatches, PREG_SET_ORDER, 0);
                            preg_match_all('/WKST=([a-zA-Z0-9]+)/m', $recurrence, $wkstMatches, PREG_SET_ORDER, 0);
                            preg_match_all('/BYDAY=([a-zA-Z0-9,]+)/m', $recurrence, $byDayMatches, PREG_SET_ORDER, 0);

                            if (isset($iterationsMatches[0]) && isset($iterationsMatches[0][1])) {
                                $iterations = (int)$iterationsMatches[0][1];
                            }

                            for ($i = 0; $i < $iterations; $i++) {
                                $event = clone $event;

                                $interval = 1;
                                if (isset($intervalMatches[0]) && isset($intervalMatches[0][1])) {
                                    $interval = $intervalMatches[0][1];
                                }

                                $dateStart = new DateTime($event->getDateStart(), $timezone);
                                $dateEnd = new DateTime($event->getDateEnd(), $timezone);

                                if (isset($freqMatches[0]) && isset($freqMatches[0][1]) && !isset($byDayMatches[0][1])) {
                                    switch ($freqMatches[0][1]) {
                                        case 'WEEKLY':
                                            $dateStart->modify('+' . $interval . ' week');
                                            $dateEnd->modify('+' . $interval . ' week');
                                            break;
                                        case 'DAILY':
                                            $dateStart->modify('+' . $interval . ' days');
                                            $dateEnd->modify('+' . $interval . ' days');
                                            break;
                                        case 'MONTHLY':
                                            $dateStart->modify('+' . $interval . ' month');
                                            $dateEnd->modify('+' . $interval . ' month');
                                            break;
                                        case 'YEARLY':
                                            $dateStart->modify('+' . $interval . ' year');
                                            $dateEnd->modify('+' . $interval . ' year');
                                            break;
                                    }


                                    $event->setDateStart($dateStart->format('Y-m-d H:i:s'));
                                    $event->setDateEnd($dateEnd->format('Y-m-d H:i:s'));

                                    if (isset($untilMatches[0][1]) && $dateStart->format('Ymd') > $untilMatches[0][1]) {
                                        break;
                                    }

                                    $event->setId('redoo_calendar_clone_' . uniqid() . '_' . $eventId);
                                    $calendar->setEvent($event);
                                }
                                if (isset($byDayMatches[0][1])) {
                                    $originDateStart = clone $dateStart;
                                    $originDateEnd = clone $dateEnd;


                                    foreach (explode(',', $byDayMatches[0][1]) as $day) {
                                        $event = clone $event;
                                        switch ($day) {
                                            case 'MO':
                                                $dateStart->modify('monday');
                                                $dateEnd->modify('monday');
                                                break;
                                            case 'TU':
                                                $dateStart->modify('tuesday');
                                                $dateEnd->modify('tuesday');
                                                break;
                                            case 'WE':
                                                $dateStart->modify('wednesday');
                                                $dateEnd->modify('wednesday');
                                                break;
                                            case 'TH':
                                                $dateStart->modify('thursday');
                                                $dateEnd->modify('thursday');
                                                break;
                                            case 'FR':
                                                $dateStart->modify('friday');
                                                $dateEnd->modify('friday');
                                                break;
                                            case 'SA':
                                                $dateStart->modify('saturday');
                                                $dateEnd->modify('saturday');
                                                break;
                                            case 'SU':
                                                $dateStart->modify('sunday');
                                                $dateEnd->modify('sunday');
                                                break;
                                        }

                                        $dateStart->setTime($originDateStart->format('h'), $originDateStart->format('i'));
                                        $dateEnd->setTime($originDateEnd->format('h'), $originDateEnd->format('i'));

                                        if ($dateStart->getTimestamp() === $originDateStart->getTimestamp()) continue;

                                        $event->setDateStart($dateStart->format('Y-m-d H:i:s'));
                                        $event->setDateEnd($dateEnd->format('Y-m-d H:i:s'));
                                        $event->setId('redoo_calendar_clone_' . uniqid() . '_' . $eventId);
                                        $calendar->setEvent($event);

                                    }

                                    $event = clone $event;

                                    $dateStart->modify('+' . $interval - 1 . ' week');
                                    $dateEnd->modify('+' . $interval - 1 . ' week');

                                    $event->setDateStart($dateStart->format('Y-m-d H:i:s'));
                                    $event->setDateEnd($dateEnd->format('Y-m-d H:i:s'));

                                }


                            }
                        }
                    }
                }
            }
        }

        return $this;
    }


    /**
     * Get calendars collection
     *
     * @return BaseExternalCollection
     * @throws \Exception
     */
    public function getCalendarCollection(): CollectionInterface
    {
        $this->getApiClient();
        $timezone = $this->getUserTimeZone();
        if ($this->apiClient) {

            $calendarService = new \Google_Service_Calendar($this->apiClient);
            $calendarCollection = new CalendarGoogleCollection();

            /** @var \Google_Service_Calendar_CalendarListEntry $item */
            foreach ($calendarService->calendarList->listCalendarList()->getItems() as $_calendar) {
                $calendar = new CalendarGoogle();
                $calendar->setId($_calendar->getId());
                $calendar->setTitle($_calendar->getSummary());
                $calendar->setColor($_calendar->getBackgroundColor());
                $this->initEvents($calendar);

                $calendarCollection->setItem($calendar);
            }

            return $calendarCollection;
        } else {
            throw new \Exception('api client not provided');
        }
    }

    /**
     * Create calendar
     *
     * @param \Vtiger_Request $request
     * @return CalendarInterface
     * @throws \Google_Exception
     */
    public function createCalendar(\Vtiger_Request $request): CalendarInterface
    {
        //var_dump($request->get('title'));die();

        $this->getApiClient();

        $calendar = new CalendarGoogle($this->apiClient);
        $calendar->setTitle($request->get('title'));
        $calendar->setColor($request->get('color'));
        $calendar->setConnection($request->get('connector'));
        $calendar->save();

        $subscription = new Subscribe();
        $subscription->setConnectionId($calendar->getConnection());
        $subscription->setCalendarId($calendar->getId());
        $subscription->setVisible(true);
        $subscription->save();

        return $calendar;
    }

    public function getEvent(CalendarInterface $calendar, $eventId): EventInterface
    {
        $this->getApiClient();
        $timezone = $this->getUserTimeZone();

        $calendarService = new \Google_Service_Calendar($this->apiClient);

        if (strpos($eventId, 'redoo_calendar_clone') === 0) {
            $eventId = str_replace('redoo_calendar_clone', '', $eventId);
            preg_match_all('/_.+_(.+)/m', $eventId, $matches, PREG_SET_ORDER, 0);

            if (isset($matches[0][1])) {
                $eventId = $matches[0][1];
            } else {
                throw new \Exception('Invalid google event id');
            }
        }

        $_event = $calendarService->events->get($calendar->getId(), $eventId);

        $event = new EventGoogle($this->apiClient);
        $event->setId($_event->getId());
        $event->setCalendarId($calendar->getId());

        foreach ($_event->getRecurrence() as $recurrence) {
            $event->setRecurrence('yes');

            preg_match_all('/COUNT=([a-zA-Z0-9]+)/m', $recurrence, $iterationsMatches, PREG_SET_ORDER, 0);
            preg_match_all('/FREQ=([a-zA-Z0-9]+)/m', $recurrence, $freqMatches, PREG_SET_ORDER, 0);
            preg_match_all('/INTERVAL=([a-zA-Z0-9]+)/m', $recurrence, $intervalMatches, PREG_SET_ORDER, 0);
            preg_match_all('/BYDAY=([a-zA-Z0-9,]+)/m', $recurrence, $byDayMatches, PREG_SET_ORDER, 0);
            preg_match_all('/UNTIL=([a-zA-Z0-9,]+)/m', $recurrence, $untilMatches, PREG_SET_ORDER, 0);
            preg_match_all('/COUNT=([a-zA-Z0-9,]+)/m', $recurrence, $countMatches, PREG_SET_ORDER, 0);
            preg_match_all('/WKST=([a-zA-Z0-9]+)/m', $recurrence, $wkstMatches, PREG_SET_ORDER, 0);

            $event->setRecurrencePreset('other');
            if (isset($freqMatches[0][1]) && !isset($intervalMatches[0][1])) {
                $event->setRecurrencePreset(strtolower($freqMatches[0][1]));
            }

            if (isset($freqMatches[0][1]) && isset($intervalMatches[0][1]) && !isset($wkstMatches[0][1])) {
                $event->setRecurrencePeriodType(strtolower($freqMatches[0][1]));
            }

            if (isset($intervalMatches[0][1])) {
                $event->setRecurrencePeriod($intervalMatches[0][1]);
            }

            if (isset($iterationsMatches[0][1])) {
                $event->setRecurrencePeriodEndAfter($iterationsMatches[0][1]);
            }

            if (isset($byDayMatches[0][1])) {
                $event->setRecurrenceWeekdays(explode(',', $byDayMatches[0][1]));
            }

            if (isset($untilMatches[0][1])) {
                $dateString = $untilMatches[0][1];
                $dateString = substr_replace($dateString, '-', 4, 0);
                $dateString = substr_replace($dateString, '-', 7, 0);

                $event->setRecurrencePeriodEnd('date');
                $event->setRecurrencePeriodEndDate($dateString);
            }

            if (isset($countMatches[0][1])) {
                $event->setRecurrencePeriodEnd('after');
                $event->setRecurrencePeriodEndAfter($countMatches[0][1]);
            }


        }

        $event->setDescription($_event->getDescription());
        $event->setTitle($_event->getSummary());

        if ($_event->getStart()->getDateTime() == null) {
            $event->setAllDayEvent('yes');

            $event->setDateStart(
                (new \DateTime($_event->getStart()->getDate()))
                    ->setTimezone($timezone)
                    ->format('Y-m-d H:i:s'));
            $event->setDateEnd(
                (new \DateTime($_event->getEnd()->getDate()))
                    ->setTimezone($timezone)
                    ->format('Y-m-d H:i:s'));
        } else {
            $event->setDateStart(
                (new \DateTime($_event->getStart()->getDateTime()))
                    ->setTimezone($timezone)
                    ->format('Y-m-d H:i:s'));
            $event->setDateEnd(
                (new \DateTime($_event->getEnd()->getDateTime()))
                    ->setTimezone($timezone)
                    ->format('Y-m-d H:i:s'));
        }

        return $event;
    }

    public function getCalendar(string $id): CalendarInterface
    {
        $this->getApiClient();
        $calendarService = new \Google_Service_Calendar($this->apiClient);
        $_calendar = $calendarService->calendarList->get($id);
        $calendar = new CalendarGoogle($this->apiClient);
        $calendar->setId($_calendar->getId());
        $calendar->setTitle($_calendar->getSummary());

        $subscribe = new Subscribe();
        $subscribe->fetchByCalendarId($calendar->getId(), $this->getId());

        $calendar->setColor($subscribe->getColor());

        return $calendar;
    }

    public function createEvent(\Vtiger_Request $request): EventInterface
    {
        $this->getApiClient();
        $eventGoogle = new EventGoogle($this->apiClient);
        $eventGoogle->setConnector($request->get('connector'));
        $eventGoogle->setTitle($request->get('title'));

        $eventGoogle->setAllDayEvent($request->get('all_day_event') == 'yes' ? true : false);

        $eventGoogle->setRecurrence($request->get('recurrence'));

        $eventGoogle->setRecurrence($request->get('recurrence'));
        $eventGoogle->setRecurrencePreset($request->get('recurrence_preset'));
        $eventGoogle->setRecurrencePeriod($request->get('recurrence_period'));
        $eventGoogle->setRecurrenceWeekdays($request->get('recurrence_weekdays'));
        $eventGoogle->setRecurrencePeriodType($request->get('recurrence_period_type'));
        $eventGoogle->setRecurrencePeriodEnd($request->get('recurrence_period_end'));
        $eventGoogle->setRecurrencePeriodEndDate($request->get('recurrence_period_end_date'));
        $eventGoogle->setRecurrencePeriodEndAfter($request->get('recurrence_period_end_after'));

        $eventGoogle->setGuest($request->get('guest'));

        $eventGoogle->setLocation($request->get('location'));

        $eventGoogle->setBusyness($request->get('busyness'));

        $eventGoogle->setReminder($request->get('reminder'));
        $eventGoogle->setReminderTime($request->get('reminder_time'));

        $eventGoogle->setCalendarId($request->get('calendar_id'));

        $timezone = new DateTimeZone('UTC');

        $eventGoogle->setDateStart(
            (new DateTime('@' . $request->get('date_start_timestamp')))
                ->setTimezone($timezone)
                ->format(\DateTime::ISO8601)
        );

        $eventGoogle->setDateEnd(
            (new DateTime('@' . $request->get('date_end_timestamp')))
                ->setTimezone($timezone)
                ->format(\DateTime::ISO8601)
        );

        $eventGoogle->setDescription($request->get('description'));
        $eventGoogle->setVisibility($request->get('privacy_type'));

        $str = $request->get('guest');
        $arr = explode(',', $str);
        $emp = [];
        foreach ($arr as $item) {
            $test = new \Google_Service_Calendar_EventAttendee();
            $test->email = trim($item);
            $emp[] = $test;
        }
        $eventGoogle->setAttendees($emp);


        $eventGoogle->save();

        $timezone = $this->getUserTimeZone();

        $eventGoogle->setDateStart(
            (new \DateTime($eventGoogle->getDateStart()))
                ->setTimezone($timezone)
                ->format('Y-m-d H:i:s'));


        $eventGoogle->setDateEnd(
            (new \DateTime($eventGoogle->getDateEnd()))
                ->setTimezone($timezone)
                ->format('Y-m-d H:i:s'));

        return $eventGoogle;

    }

    public function updateCalendar(CalendarInterface $calendar): CalendarInterface
    {
        return $calendar->save();
    }

    public function updateEvent(\Vtiger_Request $request): EventInterface
    {
        $this->getApiClient();

        $eventGoogle = new EventGoogle($this->apiClient);

        $eventId = $request->get('id');

        if (strpos($eventId, 'redoo_calendar_clone') === 0) {
            $eventId = str_replace('redoo_calendar_clone', '', $eventId);
            preg_match_all('/_.+_(.+)/m', $eventId, $matches, PREG_SET_ORDER, 0);

            if (isset($matches[0][1])) {
                $eventId = $matches[0][1];
            } else {
                throw new \Exception('Invalid google event id');
            }
        }
        $eventGoogle->setId($eventId);

        $eventGoogle->setConnector($request->get('connector'));
        $eventGoogle->setTitle($request->get('title'));

        $eventGoogle->setAllDayEvent($request->get('all_day_event') === 'yes' || $request->get('all_day_event') === 'true' ? true : false);

        $eventGoogle->setRecurrence($request->get('recurrence'));

        $eventGoogle->setRecurrence($request->get('recurrence'));
        $eventGoogle->setRecurrencePreset($request->get('recurrence_preset'));
        $eventGoogle->setRecurrencePeriod($request->get('recurrence_period'));
        $eventGoogle->setRecurrenceWeekdays($request->get('recurrence_weekdays'));
        $eventGoogle->setRecurrencePeriodType($request->get('recurrence_period_type'));
        $eventGoogle->setRecurrencePeriodEnd($request->get('recurrence_period_end'));
        $eventGoogle->setRecurrencePeriodEndDate($request->get('recurrence_period_end_date'));
        $eventGoogle->setRecurrencePeriodEndAfter($request->get('recurrence_period_end_after'));

        $eventGoogle->setGuest($request->get('guest'));

        $eventGoogle->setLocation($request->get('location'));

        $eventGoogle->setBusyness($request->get('busyness'));

        $eventGoogle->setReminder($request->get('reminder'));
        $eventGoogle->setReminderTime($request->get('reminder_time'));

        $eventGoogle->setCalendarId($request->get('calendar_id'));

        $timezone = new DateTimeZone('UTC');

        $eventGoogle->setDateStart(
            (new DateTime('@' . $request->get('date_start_timestamp')))
                ->setTimezone($timezone)
                ->format(\DateTime::ISO8601)
        );

        $eventGoogle->setDateEnd(
            (new DateTime('@' . $request->get('date_end_timestamp')))
                ->setTimezone($timezone)
                ->format(\DateTime::ISO8601)
        );

        $eventGoogle->setDescription($request->get('description'));
        $eventGoogle->setVisibility($request->get('privacy_type'));

        $str = $request->get('guest');
        $arr = explode(',', $str);
        $emp = [];
        foreach ($arr as $item) {
            $test = new \Google_Service_Calendar_EventAttendee();
            $test->email = trim($item);
            $emp[] = $test;
        }
        $eventGoogle->setAttendees($emp);

        $eventGoogle->update();

        return $eventGoogle;
    }

    public function deleteCalendar(string $id): bool
    {
        $this->getApiClient();

        return $calendar = $this->getCalendar($id)->delete();
    }

    public function deleteEvent(EventInterface $event): bool
    {
        return $event->delete();
    }

    public function getUnsubscribedCalendarCollection(): array
    {
        $subscribeCollection = new SubscribeCollection();
        $subscribeCollection->fetch([
            [
                'column' => 'connection_id',
                'value' => $this->getId()
            ]
        ]);


        return array_filter($this->getCalendarCollection()->getItemsAsArray(), function ($item) use ($subscribeCollection) {
            return !in_array($item['id'], $subscribeCollection->getCalendarIds());
        });
    }

    public function getShareUserList(Group &$group, CalendarInterface $calendar = null)
    {
        $users = \Users_Record_Model::getAll(true);

        $userList = [];

        /** @var \Users_Record_Model $user */
        foreach ($users as $user) {
            $userList[$user->getId()] = $user->getName();
        }

        $group->addField()
            ->setLabel('Share To')
            ->setBindValue('share_to')
            ->setName('share_to')
            ->setOptions([
                'multiple' => true,
                'options' => $userList
            ])
            ->setRelated([
                'access_mode' => ['share'],
            ])
            ->setValue([-1])
            ->setType(Field::INPUT_PICKLIST);

        foreach ($users as $user) {
            $group->addField()
                ->setLabel('Access to ' . $user->getName())
                ->setBindValue('share_to_' . $user->getId())
                ->setName('share_to_' . $user->getId())
                ->setOptions([
                    'options' => [
                        'read' => 'Read',
                        'write' => 'Write'
                    ]
                ])
                ->setRelated([
                    'access_mode' => ['share'],
                    'share_to' => [$user->getId()]
                ])
                ->setValue([-1])
                ->setType(Field::INPUT_PICKLIST);
        }
    }
}
